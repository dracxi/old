d = {
    "z":"gdgf",
    "y":"dfs",
    "x":"dfdfd"
}
k =  [x for x in d.keys()]
v = [x for x in d.values()]
for x in k:
    print(f"{x}: {d[x]}")