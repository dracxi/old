import requests 
import json
data = {
  "avatarId": "1622978189668552705",
  "faceShape": "normal",
  "materialIds": [
    "1610913803101876226",
    "1556896857381064705",
    "1579350974187368449",
    "1608024852120809474",
    "1556936528907653122",
    "1575431517196443649",
    "1559460367063502850",
    "1559134067505418242",
    "1559443424252186626"
  ],
  "url": "upload/57eaf0a60ffe84bb2c0c270b3b567427.gif",
  "skinColor": "#ffffffff"
}

data_page = {
  "pageId": "1623391340155830274",
  "planeId": "0",
  "boardId": "0",
  "rootId": "0",
  "type": 1,
  "safeStatus": 0,
  "resource": "{\"transform\":[0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,199,113,28,231,0,93,203,61,85,85,85,220,112,242,243,189,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63],\"blocks\":[{\"width\":1490.9754510829441,\"height\":null,\"text\":\"‎ \",\"textAlign\":2,\"backgroundColor\":0,\"fontFamily\":\"System\",\"fontColor\":4294638330,\"fontSize\":14,\"fontWeight\":3,\"type\":99,\"id\":null,\"url\":null,\"portal\":null,\"matrix4\":[0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63]},{\"width\":1072.8320766166028,\"height\":null,\"text\":\"‎ \",\"textAlign\":2,\"backgroundColor\":0,\"fontFamily\":\"System\",\"fontColor\":4294638330,\"fontSize\":14,\"fontWeight\":3,\"type\":99,\"id\":null,\"url\":null,\"portal\":null,\"matrix4\":[0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63]},{\"width\":342.05821632205436,\"height\":null,\"text\":\" \",\"textAlign\":2,\"backgroundColor\":0,\"fontFamily\":\"System\",\"fontColor\":4294638330,\"fontSize\":14,\"fontWeight\":3,\"type\":99,\"id\":null,\"url\":null,\"portal\":null,\"matrix4\":[0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,255,255,255,255,119,93,203,189,28,199,113,28,75,242,243,61,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63]},{\"width\":363.73378037718453,\"height\":null,\"text\":\"  \",\"textAlign\":2,\"backgroundColor\":0,\"fontFamily\":\"System\",\"fontColor\":4294638330,\"fontSize\":14,\"fontWeight\":3,\"type\":99,\"id\":null,\"url\":null,\"portal\":null,\"matrix4\":[0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,255,255,255,255,119,93,203,189,28,199,113,28,75,242,243,61,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63]},{\"width\":1000.73378037718453,\"height\":null,\"text\":\"   \\n\\n\",\"textAlign\":2,\"backgroundColor\":0,\"fontFamily\":\"System\",\"fontColor\":4294638330,\"fontSize\":14,\"fontWeight\":3,\"type\":99,\"id\":null,\"url\":null,\"portal\":null,\"matrix4\":[0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63,0,0,0,0,0,0,0,0,255,255,255,255,119,93,203,189,28,199,113,28,75,242,243,61,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,63]}],\"background\":\"upload/1d5e1f6532e6e280296251dd5c7efabd.gif\",\"cols\":400,\"rows\":670}",
  "name": "",
  "cover": "upload/05707116b4724ce80152bbb412caf961.gif",
  "tags": [],
  "ocId": "0",
  "ocName": "DracX",
  "ocStatusId": "0",
  "ocUrl": "upload/5dbaed82186fb015455f11d18529c137.png"
}
header = {
    'pinpon-auth':"eyJ0eXAiOiJKc29uV2ViVG9rZW4iLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJwaW5wb24iLCJhdWQiOiIxNjIyOTc4MTgzODA0OTE1NzEzIiwiYXBwVXNlcklkIjoxNjIyOTc4MTgzODA0OTE1NzEzLCJleHAiOjE2OTczOTA0NzJ9.tnYzjUX5NYQHymivNrWtJebBU-XrpskZJcvRvtgNyT0",
    'content-type': "application/json",
    'language':'en_US',
    'user-agent':'Dart/3.1 (dart:io)'
}

def pfp():
    req = requests.post(url="https://wg6.pinpon.cool/pinpon-app-system/app-avatar/update",headers=header, data=json.dumps(data_page))
    print(req.json())
def page():
    req = requests.post(url="https://wg6.pinpon.cool/pinpon-app-system/app-page/update",data=json.dumps(data_page),headers=header)
    print(req.json())

page()